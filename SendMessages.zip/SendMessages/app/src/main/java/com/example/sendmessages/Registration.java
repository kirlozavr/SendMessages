package com.example.sendmessages;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registration extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextNumberPassword;
    private Button buttonRegistration;
    private static final String DB_URL = "https://sendmessages-1b48d-default-rtdb.asia-southeast1.firebasedatabase.app/";
    private static final String DB_USERNAME = "w999088f";
    private static final String DB_PASSWORD = "uoLe40rb";
    private final FirebaseDatabase databaseRegistration = FirebaseDatabase.getInstance();
    private final DatabaseReference databaseRegistrationReference = databaseRegistration.getReference();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);
        editTextName = findViewById(R.id.editTextName);
        editTextNumberPassword = findViewById(R.id.editTextNumberPassword);
        buttonRegistration = findViewById(R.id.buttonRegistration);
        databaseRegistrationReference.child().setValue("2341");

        buttonRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editTextName.getText().toString().trim().equals("")) {
                    Toast.makeText(Registration.this, R.string.Toast_name, Toast.LENGTH_LONG).show();
                } else if (editTextNumberPassword.getText().toString().trim().equals("")) {
                    Toast.makeText(Registration.this, R.string.Toast_password, Toast.LENGTH_LONG).show();
                } else {
                    try {
                        databaseRegistrationReference.setValue(editTextName.getText());
                        Log.i("Отправка данных", databaseRegistrationReference.toString());
                    } catch (Exception e) {
                        Log.i("Ошибка", "Ошибка Registration: " + e.getMessage());
                    }
                }
            }
        });
    }
}
